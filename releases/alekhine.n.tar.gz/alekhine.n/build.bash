cp ./Source/sol.py ./sol
cp ./Source/employee.py ./employee.py
chmod +x ./sol